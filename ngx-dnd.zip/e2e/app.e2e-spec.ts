import { NgDndPage } from './app.po';

describe('ng-dnd App', () => {
  let page: NgDndPage;

  beforeEach(() => {
    page = new NgDndPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
