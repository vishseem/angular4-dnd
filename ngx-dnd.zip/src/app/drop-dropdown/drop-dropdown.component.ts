import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drop-dropdown',
  template: `<select class="form-control dropstyle">  
        <option>menu 1</option>  
        <option>menu 2</option>  
    </select> `,
  styleUrls: ['./drop-dropdown.component.css']
})
export class DropDropdownComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
