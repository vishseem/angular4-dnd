import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DropDropdownComponent } from './drop-dropdown.component';

describe('DropDropdownComponent', () => {
  let component: DropDropdownComponent;
  let fixture: ComponentFixture<DropDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DropDropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
