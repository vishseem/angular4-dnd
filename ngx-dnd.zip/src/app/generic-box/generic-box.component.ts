import { Component, OnInit,Input } from '@angular/core';
import { Properties } from '../classes/properties';
import { PropertiesService } from '../services/properties.service';

@Component({
  selector: 'app-generic-box',
  templateUrl: './generic-box.component.html',
  // template: `<input type="text" class="txtStyle col-md-4" id="{{properties.id}}" [ngStyle]="{'transform': 'translate(' + width + ',' + height + ')'}"
  //           placeholder="{{properties.placeholder}}" name="{{properties.name}}" 
  //           [dndType]="model.type"
  //           [dndDraggable] 
  //           (dndMoved)="removeItem(model, list)" 
	//           [dndObject]="model">`, 
  styleUrls: ['./generic-box.component.css']
})
export class GenericBoxComponent implements OnInit {
  @Input() model: { type: string, id: number, columns };
  @Input() list: any[];

  @Input()
  genericBox1:Object;

  @Input() properties: string ;
  propertyArray; eleStyle: Array<any> = [];width;height;

  constructor(private _propertyService: PropertiesService) { }
  

  ngOnInit() {
    console.log('Text Box');
    // this.propertyArray = this._propertyService._propertyServiceObj;
    // this.eleStyle = this._propertyService.getElementPosition(this.properties,this.propertyArray);
    // if(this.eleStyle != undefined){
    //   this.width = this.eleStyle[0];
    //   this.height = this.eleStyle[1];
    // console.log('eleStyle '+ this.eleStyle[0]);
    // }
  	// if (!this.genericBox1){ 
  	// 	this.genericBox1 = {name:'Generic Box 1', content:'Generic Box 1 Content'}
  	// }
  }

  public removeItem(item: any, list: any[]): void {
    list.splice(list.indexOf(item), 1);
  }
}
