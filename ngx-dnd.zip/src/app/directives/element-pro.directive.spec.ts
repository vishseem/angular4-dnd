import { ElementProDirective } from './element-pro.directive';

describe('ElementProDirective', () => {
  it('should create an instance', () => {
    const directive = new ElementProDirective();
    expect(directive).toBeTruthy();
  });
});
