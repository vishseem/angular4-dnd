import { Directive, ElementRef, Renderer2, OnInit, HostListener } from '@angular/core';
import { Properties } from '../classes/properties';
import { PropertiesService } from '../services/properties.service';

@Directive({
  selector: '[appElementPro]'
})
export class ElementProDirective implements OnInit {
  propertyArray;
  propertyObj;
  index; style;
  constructor(private elem: ElementRef, private renderer: Renderer2, private _propertyService: PropertiesService) {
    this.propertyObj = new Properties();
  }
  ngOnInit() {

  }
  @HostListener('click') onClick() {
    this.propertyArray = this._propertyService._propertyServiceObj;
    let id = this.elem.nativeElement.firstElementChild.id;

    this.style = this.elem.nativeElement.style.cssText;
    for (let prop of this.propertyArray) {
      if (prop.id == id) {
        this.index = this.propertyArray.indexOf(prop);
      }
    }

    let len = this.style.length;
    let x = this.style.slice(41, len - 2);
    let axis = x.split(',');
    console.log('X '+ axis[0] + ' Y '+ axis[1]);
    this.propertyArray[this.index].cssStyleX = axis[0];
    this.propertyArray[this.index].cssStyleY = axis[1];
  }

}
