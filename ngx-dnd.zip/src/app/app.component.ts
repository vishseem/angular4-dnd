import { Component, trigger, state, style, transition, animate } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        transform: 'translate3d(0, 0, 0)'
      })),
      state('out', style({
        transform: 'translate3d(100%, 0, 0)'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
  ]
})
export class AppComponent {
  labelBox = [{ name: 'Generic Box 1', content: 'Generic Box 1 Content', id: "1" }];
  genericBox = [{ name: 'Generic Box 1', content: 'Generic Box 1 Content', id: "2" }];
  dropdownBox = [{ name: 'Generic Box 1', content: 'Generic Box 1 Content', id: "3" }];
  menuState: string = 'out';
  constructor() { }
  toggleMenu() {
    this.menuState = this.menuState === 'out' ? 'in' : 'out';
  }
  private releaseDrop(event) {
  }

  /*------------*/
  public dragList = [[
    { name: 'Section', type: 'section', columns: [[]], id: 1, icon: 'fa-columns' },
    { name: 'Div', type: 'div', columns: [[]], id: 2, icon: 'fa-square-o' },
    { name: 'Table', type: 'table', id: 3, icon: 'fa-table' },
    // { name: 'Label', type: 'label', id: 4 },
    { name: 'Text Field', type: 'genericbox', id: 5, icon: 'fa-terminal' },
    { name: 'Dropdown', type: 'dropdown', id: 6, icon: 'fa-th-list' }
  ]];
}
