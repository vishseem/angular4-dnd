import { Component, OnInit, Input } from '@angular/core';
import { Properties } from '../classes/properties';
import { PropertiesService } from '../services/properties.service';

@Component({
  selector: 'app-label',
  template: `<label class="lblStyle col-md-4" id="{{properties.id}}" [ngStyle]="{'transform': 'translate(' + width + ',' + height + ')'}" 
  [dndType]="model.type"
  [dndDraggable] 
  (dndMoved)="removeItem(model, list)" 
	[dndObject]="model">{{properties.name}}</label>`,
  styleUrls: ['./label.component.css']
})
export class LabelComponent implements OnInit {

  @Input() model: { type: string, id: number, columns };
  @Input() list: any[];


  @Input() properties: string;
  // propertyArray; eleStyle: Array<any> = [];width;height;
  constructor(private _propertyService: PropertiesService) { }

  ngOnInit() {
    // debugger;
    // this.propertyArray = this._propertyService._propertyServiceObj;
    // this.eleStyle = this._propertyService.getElementPosition(this.properties,this.propertyArray);
    // if(this.eleStyle != undefined){
    //   this.width = this.eleStyle[0];
    //   this.height = this.eleStyle[1];
    // }
  }

  public removeItem(item: any, list: any[]): void {
    list.splice(list.indexOf(item), 1);
  }

}
 
