import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-section',
  templateUrl: './section.component.html',
  styleUrls: ['./section.component.css']
})
export class SectionComponent implements OnInit {

  @Input() model: { type: string, id: number, columns };
  @Input() list: any[];

  allowedTypesList = ['section','div', 'table', 'label', 'genericbox', 'dropdown'];
  sectionCols = [{
    class: 6,
    id: 1,
    model: { "name": "Section", "type": "section", "columns": [ [] ], "id": 4, "icon": "fa-columns" }
  },
  {
    class: 6,
    id: 2,
    model: { "name": "Section", "type": "section", "columns": [ [] ], "id": 5, "icon": "fa-columns" }
  }]; 

  public isArray(object): boolean {
    return Array.isArray(object);
  }

  constructor() { }

  ngOnInit() {
    //console.log(this.model);
    // for(let i of this.sectionCols) {
    //   //i.model.push(this.model);      
    //   i.model = this.model;
    //   i.model.id += i.model.id;      
    //   console.log(i);
    //   console.log(i.model);
    // }
  }

}
