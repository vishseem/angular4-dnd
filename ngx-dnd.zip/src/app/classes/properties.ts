export class Properties {
    _elementid : number;
    _id: number;
    id: any;
    name: string;
    placeholder?: string;
    cssStyleX : string;
    cssStyleY : string;
    _oldcssStyleX : number;
    _oldcssStyleY : number;
}
