import { Component, OnInit, Input } from '@angular/core';
import { NgForm} from '@angular/forms';
//import { LocalStorageService} from 'ngx-webstorage';  // private storage:LocalStorageService,
import { Properties } from '../classes/properties';
import { PropertiesService } from '../services/properties.service';

@Component({
  selector: 'app-property-window',
  templateUrl: './property-window.component.html',
  styleUrls: ['./property-window.component.css']
})
export class PropertyWindowComponent implements OnInit {
  propertyArray;
  myFormArray : Array<any>=[];
  index : number;
  constructor(private _propertyService: PropertiesService) {}

  @Input() setProperties :Array<any> = [];

  ngOnInit() { 
  }

  saveProperties(myForm: NgForm){
    this.propertyArray = this._propertyService._propertyServiceObj;
    //this.myFormArray.push(myForm.value);
    for(let prop of this.propertyArray){
      if(prop._id == myForm.value._id){
        this.index = this.propertyArray.indexOf(prop);
      }
    }
    this.propertyArray[this.index] = myForm.value;
   // this._propertyService._propertyServiceObj = Object.assign({}, this.propertyArray);
  }
}
