import { Injectable } from '@angular/core';
import { Properties } from '../classes/properties';

@Injectable()
export class PropertiesService {
  propertiesDetails : Properties[];
  _propertyServiceObj: object;
  axisX: number; axisY: number;
  index;
  tempArray: Array<any> = [];
  styleArray : Array<any> = [];
  
  constructor() {}

  getElementPosition(properties,propertyArray) {
    this.styleArray=[];this.tempArray=[];
    this.tempArray.push(properties);
    let id = this.tempArray[0]._id;
    
    let x = this.tempArray[0].cssStyleX.split('px');
    let y = this.tempArray[0].cssStyleY.split('px');

    for (let prop of propertyArray) {
      if (prop._id == id) {
        this.index = propertyArray.indexOf(prop);
      }
    }
    if (x[0] != "0" && y[0] != "0") {
      let oldX = propertyArray[this.index]._oldcssStyleX;
      if (oldX != x) {
        this.axisX = parseInt(oldX) + parseInt(x[0]);
        this.styleArray[0]= this.axisX + 'px';
        propertyArray[this.index]._oldcssStyleX = this.axisX;
       // console.log('oldX ' + oldX + ' axisX ' + this.axisX + ' width ' + this.width);
      }

      let oldY = propertyArray[this.index]._oldcssStyleY;
      if (oldY != y) {
        this.axisY = parseInt(oldY) + parseInt(y[0]);
        this.styleArray[1]=this.axisY + 'px';
        propertyArray[this.index]._oldcssStyleY = this.axisY;
      }
      return this.styleArray;
    }
  }

}
