import { NgModule } from '@angular/core';
//import { NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ContextMenuModule } from 'angular2-contextmenu';
//import { Ng2Webstorage } from 'ngx-webstorage';
import { DndListModule } from 'ngx-drag-and-drop-lists';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { AppComponent } from './app.component';
//import { DragDropDirectiveModule} from "angular4-drag-drop";
import { DropAreaComponent } from './drop-area/drop-area.component';
import { GenericBoxComponent } from './generic-box/generic-box.component';
import { DropDropdownComponent } from './drop-dropdown/drop-dropdown.component';
//import { AngularDraggableModule } from 'angular2-draggable';
import { PropertyWindowComponent } from './property-window/property-window.component';

import { PropertiesService } from './services/properties.service';
import { LabelComponent } from './label/label.component';
import { ElementProDirective } from './directives/element-pro.directive';
import { DivComponent } from './div/div.component';
import { SectionComponent } from './section/section.component';

@NgModule({
  declarations: [
    AppComponent,
    DropAreaComponent,
    GenericBoxComponent,
    DropDropdownComponent,
    PropertyWindowComponent,
    LabelComponent,
    ElementProDirective,
    DivComponent,
    SectionComponent,
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    FormsModule,
    HttpModule,
    AngularFontAwesomeModule,
    //DragDropDirectiveModule,
    //NgbModule.forRoot(),
    //AngularDraggableModule,
    ContextMenuModule,
    //Ng2Webstorage,
    DndListModule
  ],
  providers: [PropertiesService],
  bootstrap: [AppComponent]
}) 
export class AppModule { }
