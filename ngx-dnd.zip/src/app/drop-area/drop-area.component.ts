import { Component, OnInit, Input, trigger, state, style, transition, animate } from '@angular/core';
//import { LocalStorageService } from 'ngx-webstorage';
import { Properties } from '../classes/properties';
import { PropertiesService } from '../services/properties.service';

@Component({
  selector: 'app-drop-area',
  templateUrl: './drop-area.component.html',
  styleUrls: ['./drop-area.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        transform: 'translate3d(0, 0, 0)'
      })),
      state('out', style({
        transform: 'translate3d(100%, 0, 0)'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
  ]
})
export class DropAreaComponent {

  allowedTypesList = ['section','div', 'table', 'label', 'genericbox', 'dropdown'];

  public nestedList = {
    dropzones: [[ ]]
  };


  propertyObj: Properties;
  menuState: string = 'out';
  Properties: Array<any> = [];
  private itemsLabel: Array<any> = [];
  private itemsDropped: Array<any> = [];
  private itemsDroppedDD: Array<any> = [];
  private commonArray: Array<any> = [];

  itemid: number;
  count: number = 0;
  lblcount: number = 0;
  txtcount: number = 0;
  ddlcount: number = 0;

  constructor(private _propertyService: PropertiesService) {
    this.propertyObj = new Properties();
  }

  // element drag and drop function
  private addDropItem(event) {
    this.count++;
    this.itemid = event[0].id;
    this.propertyObj._id = this.count; // unique id
    this.propertyObj.id = 'lbl' + this.count; // unique id but editable
    this.propertyObj.cssStyleY = "0";
    this.propertyObj.cssStyleX = "0";
    this.propertyObj._oldcssStyleX = 0;
    this.propertyObj._oldcssStyleY = 0;


    if (this.itemid == 1) {
      this.lblcount++;
      this.propertyObj._elementid = 1;
      this.propertyObj.name = "Label" + this.lblcount;
      let tempArray = Object.assign({}, this.propertyObj);
      this.itemsLabel.push(tempArray);
      this.commonArray.push(tempArray);
    } else if (this.itemid == 2) {
      this.txtcount++;
      this.propertyObj._elementid = 2;
      this.propertyObj.name = "Textbox" + this.txtcount;
      this.propertyObj.placeholder = "Textbox" + this.txtcount;

      let tempArray = Object.assign({}, this.propertyObj);

      this.itemsDropped.push(tempArray);
      this.commonArray.push(tempArray);
      // store property value in session
      //this.storage.store('_sessionProperties', this.itemsDropped);
    } else if (this.itemid == 3) {
      this.ddlcount++;
      this.propertyObj._elementid = 3;
      this.itemsDroppedDD.push(event);
    }
    this._propertyService._propertyServiceObj = this.commonArray;
    this.menuState = this.menuState === 'out' ? 'in' : 'in';
  }

  // property window close function
  close() {
    //this.menuState = this.menuState === 'in' ? 'out' : 'out';
  }
  temp: Array<any> = [];
  // property window open on mouse write click
  showProperties(event) {
    this.menuState = this.menuState === 'out' ? 'in' : 'in';
    this.Properties = event.item;
  }

  // element remove on mouse write click
  removeElement(event) {
    let index;
    if (event.item._elementid == 1) {
      index = this.itemsLabel.indexOf(event.item);
      (index >= 0) ? this.itemsLabel.splice(index, 1) : alert('Something went wrong');
    } else if (event.item._elementid == 2) {
      index = this.itemsDropped.indexOf(event.item);
      (index >= 0) ? this.itemsDropped.splice(index, 1) : alert('Something went wrong');
    }
    this.menuState = this.menuState === 'in' ? 'out' : 'out';
  }
}
