var $elements = document.getElementById('elements');
var $playground = document.getElementById('playground');
var drake = dragula([$elements, $playground], {
	accepts: function (el, target, source, sibling) {
		if(target.classList.contains('gu-transit') || !target.classList.contains('accept-drops')) return false;
		return true;
	},
	copy: function(el) {
		if(el.classList.contains('clone'))
			return false;
		return true;
	}
});

drake.on('drop', function(el) {
	if(el.classList.contains('elt-accepts') && !el.classList.contains('accept-drops')) {
		el.classList.add('accept-drops');
		//pseudo_containers.push(el);
	}
});