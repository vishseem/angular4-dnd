import { Component, OnInit } from '@angular/core';
import { dragula, DragulaService } from 'ng2-dragula';
import { ItemService } from '../services/item.service';

@Component({
  selector: 'app-drag-items',
  templateUrl: './drag-items.component.html',
  styleUrls: ['./drag-items.component.css']
})
export class DragItemsComponent implements OnInit {

	itemsToDrop:Array<Object>;

	// private itemsToDrop:Array<Object> = [
	// 	{
	// 		name: 'Table',
	// 		content: 'desctiption 1',
	// 		id: 'table',
	// 		rows: [1, 2, 3]
	// 	},
	// 	{
	// 		name: 'Div',
	// 		content: 'desctiption 2',
	// 		id: 'div'
	// 	},
	// 	{
	// 		name: 'Section',
	// 		content: 'desctiption 3',
	// 		id: 'section'
	// 	}
	// ]

  constructor(private dragulaService: DragulaService, private itemService: ItemService) {

		this.itemsToDrop = itemService.getItems();


		dragulaService.setOptions('bag-one', {
			// accepts: (el, target, source, sibling) => {
			// 	console.log('el :: ' + JSON.stringify(el));
			// 	console.log('target :: ' + JSON.stringify(target));
			// },
			copy: true
		});
		// dragulaService.setOptions('bag-one', {
		// 	// moves: function (el, container, target) {
		// 	// 	console.log(el);
		// 	// 	console.log(container);
		// 	// 	console.log(target);
		// 	// 	return !target.classList.contains('handle');
		// 	// }
		// 	  accepts: (el, target, source, sibling) => {
		// 			//dragulaService.add('bag-one', el.childNodes);
		// 			//dragulaService.find('bag-two').drake.containers.push('vishal')
		// 			console.log(target.childNodes[1].classList.contains('elt-accepts'));
		// 			if(target.childNodes[1].classList.contains('elt-accepts')) {
		// 				target.classList.add('accept-drops')
		// 			}
		// 			if(target.classList.contains('accept-drops')) {
		// 				target.classList.remove('accept-drops')
		// 				console.log(target.classList.contains('accept-drops'));
		// 				document.getElementById('test').innerHTML += 'vishal';
		// 				return true;
		// 			}
					
		// 			//console.log(el.childNodes.push(document.getElementById('test')));
		// 			//console.log(el.childNodes);
		// 			//console.log(dragulaService.find('bag-two').drake.containers.push('vishal'));
		// 			//console.log(dragulaService.find('bag-one').drake.containers);
					
					
		// 			// if(!target.classList.contains('accept-drops')) {
						
		// 			// } else {
		// 			// 	//console.log(el);
		// 			// 	//console.log(target);
		// 			// }	
		// 			//return dragulaService.find('bag-two').drake.containers;				
		// 		}
		// });
		
		// dragulaService.drag.subscribe((value) => {
    //   this.onDrag(value);
    // }); 
		// var $elements = document.getElementById('elements');
		// var $playground = document.getElementById('playground');
		// var drake = dragula([$elements, $playground])
		// 	.on('drag', function (el) {
		// 		//el.className = el.className.replace('ex-moved', '');
		// 		console.log(el);
		// });
		// drake.on('drag', function(el) {
		// 	console.log(el);
		// });

	}

  ngOnInit() { }

	// private onDrag(args) {
	// 	//console.log(args);
	// 	if(args[1].classList.contains('elt-accepts')) {
	// 		//console.log('acc');
	// 		//this.dragulaService.find('bag-two').drake.containers.push(document.getElementById('test'));
	// 		//console.log(this.dragulaService.find('bag-two').drake)
	// 		//this.dragulaService.add('bag-two', args[1]);
	// 	}
  //   //let [e, el] = args;
  //   //this.removeClass(e, 'ex-moved');
  // }
	
	// public $elements = document.getElementById('elements');
	// public $playground = document.getElementById('playground');
	// public drake = dragula([this.$elements, this.$playground])
	// 		.on('drag', function (el) {
	// 			//el.className = el.className.replace('ex-moved', '');
	// 			console.log(el);
	// 	});

}
