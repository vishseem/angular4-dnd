import { Component, OnInit } from '@angular/core';
import { DragulaService } from 'ng2-dragula';
import { ItemService } from '../services/item.service';

@Component({
  selector: 'app-drag-items',
  templateUrl: './drag-items.component.html',
  styleUrls: ['./drag-items.component.css']
})
export class DragItemsComponent implements OnInit {
	
	itemsToDrop:Array<Object>;
	
	constructor(private dragulaService: DragulaService, private itemService: ItemService) {
		this.itemsToDrop = itemService.getItems();

		dragulaService.setOptions('bag-one', {
            copy: true
        })
	}

	ngOnInit() { }	

}
