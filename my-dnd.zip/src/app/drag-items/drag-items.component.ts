import { Component, OnInit } from '@angular/core';
import { ItemService } from '../services/item.service';

@Component({
  selector: 'app-drag-items',
  templateUrl: './drag-items.component.html',
  styleUrls: ['./drag-items.component.css']
})
export class DragItemsComponent implements OnInit {
	
	itemsToDrop:Array<Object>;
	
	public dragList = [[
		  { name: 'Section', type: 'section', columns: [[]], id: 1 },
		  { name: 'Div', type: 'div', columns: [[]], id: 2 },
		  { name: 'Table', type: 'table', id: 3 }
	  ]];
	
	constructor(private itemService: ItemService) { 
		this.itemsToDrop = itemService.getItems();
	}

	ngOnInit() { }
	
	public removeItem(item: any, list: any[]): void {
		list.splice(list.indexOf(item), 1);
	}

}
