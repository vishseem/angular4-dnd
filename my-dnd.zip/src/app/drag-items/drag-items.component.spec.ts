import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DragItemsComponent } from './drag-items.component';

describe('DragItemsComponent', () => {
  let component: DragItemsComponent;
  let fixture: ComponentFixture<DragItemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DragItemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DragItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
