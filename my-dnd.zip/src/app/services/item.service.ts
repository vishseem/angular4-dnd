import { Injectable } from '@angular/core';

@Injectable()
export class ItemService {

  itemsToDrop:Array<Object>;

  constructor() { 
    this.itemsToDrop = [
      {
        name: 'Table',
        content: 'desctiption 1',
        id: 'table',
        rows: [1, 2, 3]
      },
      {
        name: 'Div',
        content: 'desctiption 2',
        id: 'div'
      },
      {
        name: 'Section',
        content: 'desctiption 3',
        id: 'section'
      }
    ]
  }

  getItems() {
    return this.itemsToDrop;
  }

}
