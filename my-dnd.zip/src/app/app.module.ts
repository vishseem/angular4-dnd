import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DragDropDirectiveModule} from "angular4-drag-drop";
import { DragulaModule } from 'ng2-dragula';
import { NgDraggableModule } from 'angular-draggable';


import { AppComponent } from './app.component';
import { DragItemsComponent } from './drag-items/drag-items.component';
import { DropAreaComponent } from './drop-area/drop-area.component';
import { TableComponent } from './elements/table/table.component';
import { DivComponent } from './elements/div/div.component';
import { SectionComponent } from './elements/section/section.component';
import { DivpComponent } from './properties/divp/divp.component';

import { ItemService } from './services/item.service';


@NgModule({
  declarations: [
    AppComponent,
    DragItemsComponent,
    DropAreaComponent,
    TableComponent,
    DivComponent,
    SectionComponent,
    DivpComponent
  ],
  imports: [
    BrowserModule,
	  DragDropDirectiveModule,
	  DragulaModule,
	  NgDraggableModule
  ],
  providers: [ItemService],
  bootstrap: [AppComponent]
})
export class AppModule { }
