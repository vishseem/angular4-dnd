import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drop-area',
  templateUrl: './drop-area.component.html',
  styleUrls: ['./drop-area.component.css']
})
export class DropAreaComponent implements OnInit {

  allowedTypesList = ['section','div', 'table'];

  public nestedList = {
    dropzones: [[ ]]
  };

  constructor() { }

  ngOnInit() { }

  public removeItem(item: any, list: any[]): void {
		list.splice(list.indexOf(item), 1);
	}

}
