import { Component, OnInit } from '@angular/core';
import { dragula, DragulaService } from 'ng2-dragula';
import { ItemService } from '../services/item.service';

@Component({
  selector: 'app-drop-area',
  templateUrl: './drop-area.component.html',
  styleUrls: ['./drop-area.component.css']
})
export class DropAreaComponent implements OnInit {
  allItems;
	itemsDropped:Array<any> = [];

  constructor(private dragulaService: DragulaService, private itemService: ItemService) { 
    
    this.allItems = itemService.getItems();

    dragulaService.drop.subscribe((value) => {
      this.onDrop(value);      
    });

  }

  ngOnInit() { }

  private onDrop(value) {     
    this.allItems.find(x => {
      if(x.id == value[1].id) {
        this.itemsDropped.push(x);
        console.log(this.itemsDropped);
      }
    });
  }

}
