import { Component, OnInit } from '@angular/core';
import {dragula, DragulaService} from 'ng2-dragula';
import { ItemService } from '../services/item.service';
//import {Dragula} from 'dragula';
//import { ViewChild } from '@angular/core/src/metadata/di';
//import { DivComponent } from '../elements/div/div.component';

@Component({
  selector: 'app-drop-area',
  templateUrl: './drop-area.component.html',
  styleUrls: ['./drop-area.component.css']
})
export class DropAreaComponent implements OnInit {

  //@Input() itemDetails;  

  //@ViewChild(DivComponent)
  //private divComponent: DivComponent;

  allItems;
	itemsDropped:Array<any> = [];
  // private showProperties = false;
  // public elements = document.getElementById('dragLeft');
  // public playground = document.getElementById('dropRight');
  //itemId: string;

  constructor(private dragulaService: DragulaService, private itemService: ItemService) { 
    
    this.allItems = itemService.getItems();

    dragulaService.setOptions('bag-one', {
      accepts: (el, target, source, sibling) => {
        //console.log(this.itemsDropped);
        // if(this.itemsDropped.indexOf(el.id) == -1) {
        //   this.itemsDropped.push(el.id);
        //   //console.log(this.itemsDropped);
        //   return true;
        // }
        console.log(target);
        return this.itemsDropped;
      },
      // moves: function (el, container, target) {
      //   console.log(target.classList);
      //   return true;
      // }
    });
    dragulaService.drop.subscribe((value) => {
      this.onDrop(value);      
    });
    //console.log('divComponent :: ' + this.divComponent);
    // let drake = dragula([this.elements, this.playground], {
    //   moves: function(el, ctn, target) {
    //     console.log(el);
    //     console.log(target);
    //     //return target.classList.contains('draggable') || target.classList.contains('handle');
    //   }
    // });
    // drake.on('drag', function(el) {
    //   console.log(el);
    // });
  }

  ngOnInit() { }
  
  // private addDropItem(event){
  // 	this.itemsDropped.push(event);
	//   console.log(this.itemsDropped);
  // }

  // public handleEvent(dData:any) {
  //   console.log('dData :: ' + dData);
  // }

  //(0 - bagname, 1 - el, 2 - target, 3 - source, 4 - sibling)
  private onDrop(value) {     
    this.allItems.find(x => {
      if(x.id == value[1].id) {
        this.itemsDropped.push(x);
        //console.log(this.itemsDropped);
      }
    }); 
    
    
    //console.log(value);
    // if (value[2] == null) //dragged outside any of the bags
    //   return;
    // if (value[2].id !== "content" && value[2].id !== value[3].id) //dragged to a container that should not add the element
    //   value[1].remove();
  }

  
  
  // public drake = dragula([this.elements, this.playground], {
  //   moves: function(el, ctn, target) {
  //     console.log(el);
  //     console.log(target);
  //     //return target.classList.contains('draggable') || target.classList.contains('handle');
  //   },
  //   drag: function(el) {
  //     console.log(el);
  //   }
  // });
  
  

}
