import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-div',
  templateUrl: './div.component.html',
  styleUrls: ['./div.component.css']
})
export class DivComponent implements OnInit {

  @Input() divDetails;

  constructor() { }

  ngOnInit() { }

}
