import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {DragulaService} from 'ng2-dragula';

@Component({
  selector: 'app-div',
  templateUrl: './div.component.html',
  styleUrls: ['./div.component.css']
})
export class DivComponent implements OnInit {

  @Input() divDetails;
  @Output('divData') dData = new EventEmitter<string>();

  constructor(private dragulaService: DragulaService) {
    // dragulaService.setOptions('bag-one-div', {
    //   accepts: (el, target, source, sibling) => {
    //     return !el.contains(target);
    //     //return el;
    //   },
    //   moves: function (el, container, handle) {
    //     return el;
    //   }
    // });
  }

  ngOnInit() {
    //console.log(this.divDetails);
  }
  
  public openProp() {
    //alert('clicked');
    this.dData.emit('true');
  }

}
