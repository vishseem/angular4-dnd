import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-div',
  templateUrl: './div.component.html',
  styleUrls: ['./div.component.css']
})
export class DivComponent implements OnInit {

  @Input() model: { type: string, id: number, columns };
  @Input() list: any[];

  allowedTypesList = ['section','div', 'table'];

  public isArray(object): boolean {
    return Array.isArray(object);
  }

  public removeItem(item: any, list: any[]): void {
    list.splice(list.indexOf(item), 1);
  }

  constructor() { }

  ngOnInit() { }

}
