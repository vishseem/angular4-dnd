import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  
  @Input() model: { type: string, id: number, columns };
  @Input() list: any[];
  
  tableRows = [1, 2, 3];

  constructor() { }

  ngOnInit() { }

  public removeItem(item: any, list: any[]): void {
    list.splice(list.indexOf(item), 1);
  }

}
