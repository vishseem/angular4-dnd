import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-divp',
  templateUrl: './divp.component.html',
  styleUrls: ['./divp.component.css']
})
export class DivpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
