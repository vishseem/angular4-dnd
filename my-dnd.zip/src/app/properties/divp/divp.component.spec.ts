import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DivpComponent } from './divp.component';

describe('DivpComponent', () => {
  let component: DivpComponent;
  let fixture: ComponentFixture<DivpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DivpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DivpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
